use mavenmovies;
describe rental;
-- here we have mavenmovies dataset consistin
-- g of 19 tables describing how many movie cds were rented and
-- films and about actor and about customers--
-- as my first step iam trying to undderstand data, iam goig to know what are the colums in each
-- table and what are the primary keys and how they are related--

-- here are some poits iam came with
-- 1 here we have to companies and 2 stores and two staffs in each store
-- 2 and then we have inventory table,detailigthe t=stocks we have
-- 3 rental ad payments another to importat tales
show tables;
select * from actor_info;
select * from rental order by customer_id;
select * from payment;
select * from inventory where film_id=1;
select * from film;




-- top rented films by days
-- here we have the query to get the amess of the films which are rnted most
  select  sum(days) as days , rent.film_id, rent.title
  from
  (
  select rental.inventory_id, sum(datediff(return_date,rental_date)) as days , film.film_id, title
 from rental inner join inventory on rental.inventory_id=inventory.inventory_id inner join film
 on inventory.film_id=film.film_id group by inventory_id 
 order by film_id desc ) as rent
 group by film_id order by days desc
 ;
 
 

-- Analyze the monthly rental trends over the available data period
select monthname(rental_date) as Month_name,count(rental_id) as no_of_rentals 
from rental group by monthname(rental_date);
select max(rental_date) from rental;



-- Determine the peak rental hours in a day based on rental transactions
select date_format(hours.hourss,"%H") as hourw, avg(hours.rentals_count) as avg_no_rentals from
 (select date_format(rental_date,"%y-%m-%d-%H") as hourss , count(rental_id) as Rentals_count
 from rental group by hourss) as hours
 group by hourw order by avg_no_rentals desc;
select date_format(rental_date,"%y-%m-%d-%H") as hourss , count(rental_id) as Rentals_count
 from rental group by hourss;
 
 

-- Identify the top 10 most rented films
select title, rental_duration from film order by rental_duration desc;
select title, count(rental.rental_id) as cn from film 
left join inventory on film.film_id=inventory.film_id
 left join rental on
 inventory.inventory_id= rental.inventory_id group by title order by cn desc ;
 
 


-- Determine which film categories have the highest number of rentals.
select category.name, count(rental_id) from film 
left join inventory on film.film_id=inventory.film_id
 left join rental on
 inventory.inventory_id= rental.inventory_id
 left join film_category on film_category.film_id = film.film_id
 left join category on category.category_id=film_category.category_id 
 group by category.name order by count(rental_id) desc;
 
 
 
 
 -- Identify which store generates the highest rental revenue
 select staff.store_id, sum(amount) from staff left join
 rental on staff.staff_id=rental.staff_id 
 left join payment on payment.rental_id=rental.rental_id
 group by staff.store_id;
 
 
 
 --  Determine the distribution of rentals by staff members to assess performance.
 select * from staff;
 with No_of_rentals as (select rental.staff_id, first_name,Last_name, count(*) as No_of_rentals
from rental inner join 
  staff on rental.staff_id=staff.staff_id 
  group by rental.staff_id),
  amount as(
 select staff_id,sum(amount) as Total_amount from payment group by staff_id)
 select No_of_rentals.staff_id, first_name,Last_name, No_of_rentals,Total_amount 
 from No_of_rentals inner join amount
 on No_of_rentals.staff_id=amount.staff_id;
 
 
 
 
 
  -- top customers by rentals;
select  concat(first_name," ", last_name) , count(*) as cn_ren 
 from rental inner join customer
on rental.customer_id=customer.customer_id
 group by rental.customer_id order by cn_ren desc ; 
 
 
 
 -- top customers by reveue;
select payment.customer_id,concat(first_name," ", last_name) as namess, sum(amount) as total
from payment 
inner join customer
on customer.customer_id=payment.customer_id group by payment.customer_id order by total desc;




-- for each actor represent the film count inventorycount..
with moviecout as
(select actor_id ,concat(first_name,space(1),last_name) as actor_name ,count(film_id) as movie_count 
from actor inner join film_actor using(actor_id)
group by actor_id),
invct as
(
select actor_id ,count(inventory_id) as inventory_count
from actor inner join film_actor using(actor_id) inner join inventory using(film_id)
group by actor_id)
,rental_ct as
(select actor_id ,count(rental_id) as rental_count
from actor inner join film_actor using(actor_id) inner join inventory using(film_id) inner join rental using(inventory_id)
group by actor_id),
trac_ct as
(select actor_id ,count(rental_id) as transaction_count,sum(amount) as revenue
from actor inner join film_actor using(actor_id) inner join inventory using(film_id) 
inner join rental using(inventory_id) inner join payment using(rental_id)
group by actor_id)
select * from moviecout inner join 
invct  using(actor_id) join
rental_ct  using(actor_id) join
trac_ct  using(actor_id);
  


